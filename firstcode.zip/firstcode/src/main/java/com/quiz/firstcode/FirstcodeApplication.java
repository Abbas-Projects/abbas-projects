package com.quiz.firstcode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstcodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstcodeApplication.class, args);
	}

}
